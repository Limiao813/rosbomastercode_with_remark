/****************************************************************************
 *  Copyright (C) 2019 RoboMaster.
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/*
 *  Player - One Hell of a Robot Server
 *  Copyright (C) 2000  Brian Gerkey   &  Kasper Stoy
 *                      gerkey@usc.edu    kaspers@robotics.usc.edu
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "amcl_map.h"

namespace roborts_localization {
// 构造函数
CachedDistanceMap::CachedDistanceMap(double scale,
									 double max_dist) {
	scale_ = scale;
	max_dist_ = max_dist;
	cell_radius_ = static_cast<int>(max_dist / scale); // 2.0/0.05=40 即长宽40个像素内寻找占用的格子
	distances_mat_.resize(cell_radius_ + 2);
	for (auto it = distances_mat_.begin(); it != distances_mat_.end(); ++it) {  // auto声明自动变量
		it->resize(cell_radius_ + 2, max_dist_); //第二个参数是这个it（数组）中的类型
	}

	for (int i = 0; i < cell_radius_ + 2; i++) {
		for (int j = 0; j < cell_radius_ + 2; j++) {
			distances_mat_[i][j] = std::sqrt(i * i + j * j);
		}
	} //这个构造函数作用是在创建对象的时候，创建了一个定义的42*42的表，这个表的值离原点的距离
}

AmclMap::~AmclMap() {
	cells_vec_.clear();
	cells_vec_.shrink_to_fit();
}

int AmclMap::GetSizeX() const {
	return size_x_;
}

int AmclMap::GetSizeY() const {
	return size_y_;
}

double AmclMap::GetDiagDistance() const {
	return diag_distance_;
}

int AmclMap::ComputeCellIndexByMap(const int &i, const int &j) {
	//计算第j行，第i个值在之字形队列中是序号是几
	return i + j * this->size_x_;
};

void AmclMap::ConvertWorldCoordsToMapCoords(const double &x,
											const double &y,
											int &mx,
											int &my) {
	mx = (std::floor((x - this->origin_x_) / this->scale_ + 0.5) + this->size_x_ / 2);
	my = (std::floor((y - this->origin_y_) / this->scale_ + 0.5) + this->size_y_ / 2);
}

void AmclMap::ConvertMapCoordsToWorldCoords(const int &x,
											const int &y,
											double &wx,
											double &wy) {
	wx = (this->origin_x_ + ((x) - this->size_x_ / 2) * this->scale_);
	wy = (this->origin_y_ + ((y) - this->size_y_ / 2) * this->scale_);
}

bool AmclMap::CheckMapCoordsValid(const int &i, const int &j) {
	return ((i >= 0) && (i < this->size_x_) && (j >= 0) && (j < this->size_y_));
};

void AmclMap::ConvertFromMsg(const nav_msgs::OccupancyGrid &map_msg) {
	this->size_x_ = map_msg.info.width;
	this->size_y_ = map_msg.info.height;
	this->scale_ = map_msg.info.resolution;
	this->origin_x_ = map_msg.info.origin.position.x + (this->size_x_ / 2) * this->scale_;
	this->origin_y_ = map_msg.info.origin.position.y + (this->size_y_ / 2) * this->scale_;
	this->cells_vec_.resize(this->size_x_ * this->size_y_); //设置为像素点总数
	//static_cast <type-id>( expression )将expression转化为type-id类型
	this->max_x_distance_ = static_cast<double>(this->size_x_) * scale_; //算出地图最大距离
	this->max_y_distance_ = static_cast<double>(this->size_y_) * scale_;
	this->diag_distance_ = math::EuclideanDistance<double>(0, 0, max_x_distance_, max_y_distance_);
	LOG_INFO << "max x " << max_x_distance_ << " max y " << max_y_distance_;

	for (int i = 0; i < this->size_x_ * this->size_y_; i++) {
		auto tmp_msg = static_cast<int>(map_msg.data[i]);
		if (tmp_msg == 0) {
			this->cells_vec_[i].occ_state = -1; //cells_vec_是一个向量，里面的数据类型为cell
		} else if (tmp_msg == 100) {
		//! Occupancy state (-1 = free, 0 = unknown, +1 = occ)	
			this->cells_vec_[i].occ_state = +1;
		} else {
			this->cells_vec_[i].occ_state = 0;
		} //将接收到的服务地图是否free转化为了数组，存储在对象里面 this->cell_vec_[]
	}
}

bool AmclMap::CheckIndexFree(int i, int j) { //查看该格子是否是否free
	if (this->cells_vec_[ComputeCellIndexByMap(i, j)].occ_state == -1) {
		return true;
	} else {
		return false;
	}
}
 //函数名称前面加&，代表返回的是引用
const double &AmclMap::GetMaxOccDist() const {
	return max_occ_dist_;
}

const double &AmclMap::GetCellOccDistByIndex(int cell_index) {
	return cells_vec_[cell_index].occ_dist;
}

double AmclMap::GetCellOccDistByCoord(unsigned i, unsigned j) {
	return GetCellOccDistByIndex(ComputeCellIndexByMap(i, j));
}

const nav_msgs::OccupancyGrid &AmclMap::ConvertDistanMaptoMapMsg() {
	if (!distance_map_init_) {
		//distance_map_msg_是nav_msgs::OccupancyGrid类型。格栅地图
		distance_map_msg_.header.frame_id = "map";
		distance_map_msg_.info.width = this->size_x_;
		distance_map_msg_.info.height = this->size_y_;
		distance_map_msg_.info.resolution = this->scale_;
		distance_map_msg_.info.origin.position.x = this->origin_x_ - (this->size_x_ / 2) * this->scale_;
		distance_map_msg_.info.origin.position.y = this->origin_y_ - (this->size_y_ / 2) * this->scale_;
		distance_map_msg_.data.resize(this->size_x_ * this->size_y_);
		for (int i = 0; i < this->size_x_ * this->size_y_; i++) {
			distance_map_msg_.data[i] =  //将之前存在cell_vec_[]中的地图数据，填充进官方标准格式格栅地图中
					(static_cast<int8_t >((cells_vec_[i].occ_dist) / (max_occ_dist_) * 100.0 / this->scale_));
		}
		distance_map_init_ = true;  //这样地图就完成了初始化
	}

	return distance_map_msg_;
}

void AmclMap::BuildDistanceMap(double scale, double max_dist) 
{
	cached_distance_map_.reset();
	if (cached_distance_map_ == nullptr || cached_distance_map_->scale_ != scale || cached_distance_map_->max_dist_) 
	{
		if (cached_distance_map_ != nullptr) 
		{
			cached_distance_map_.reset();
		}
		cached_distance_map_ = std::make_unique<CachedDistanceMap>(scale, max_dist);
	}
}

void AmclMap::UpdateCSpace(double max_occ_dist) {
  // value of max_occ_dist is 2.0
	mark_vec_ = std::make_unique<std::vector<unsigned char>>();
	mark_vec_->resize(this->size_x_ * this->size_y_);
	CellDataPriorityQueue Q;
	this->max_occ_dist_ = max_occ_dist;
	BuildDistanceMap(this->scale_, this->max_occ_dist_);

	// Enqueue all the obstacle cells    将所有有障碍的格子队列
	// CellDate是一个类
	CellData cell(0,
				  0,
				  0,
				  0,
				  std::bind(&AmclMap::GetCellOccDistByCoord, this, std::placeholders::_1, std::placeholders::_2));
	for (int i = 0; i < this->size_x_; i++) {
		//挑出全部的障碍格子？？？
		cell.src_i_ = cell.i_ = i;
		for (int j = 0; j < size_y_; j++) {
			auto map_index_tmp = ComputeCellIndexByMap(i, j);
			if (this->cells_vec_[map_index_tmp].occ_state == +1) {
//				cell.occ_dist_ = this->cells_vec_[map_index_tmp].occ_dist = 0.0;
				this->cells_vec_[map_index_tmp].occ_dist = 0.0;
				//!occ_dist---- Distance to the nearest occupied cell
				cell.src_j_ = cell.j_ = j;
				mark_vec_->at(map_index_tmp) = 1; //.at大致上和mark_vec_[]没有区别
				Q.push(cell);   // 我觉得这里不应该是Q，而是一个普通的数组，改改试一试
			} else {
//				cell.occ_dist_ = this->cells_vec_[map_index_tmp].occ_dist = max_occ_dist;
				this->cells_vec_[map_index_tmp].occ_dist = max_occ_dist;
			}
		}
	}

	while (!Q.empty()) {
		CellData current_cell_data = Q.top();
		if (current_cell_data.i_ > 0) {
			Enqueue(current_cell_data.i_ - 1, current_cell_data.j_,
					current_cell_data.src_i_, current_cell_data.src_j_,
					Q);
		}
		if (current_cell_data.j_ > 0) {
			Enqueue(current_cell_data.i_, current_cell_data.j_ - 1,
					current_cell_data.src_i_, current_cell_data.src_j_,
					Q);
		}
		if (current_cell_data.i_ < this->size_x_ - 1) {
			Enqueue(current_cell_data.i_ + 1, current_cell_data.j_,
					current_cell_data.src_i_, current_cell_data.src_j_,
					Q);
		}
		if (current_cell_data.j_ < this->size_y_ - 1) {
			Enqueue(current_cell_data.i_, current_cell_data.j_ + 1,
					current_cell_data.src_i_, current_cell_data.src_j_,
					Q);
		}
		Q.pop(); // 每次处理一个点的上下左右四个点,然后将剩下的继续排序弹出最小的。
		// 最后可以将整个地图每个点都遍历
	}

	cached_distance_map_.reset();
	mark_vec_.reset();
}

void AmclMap::Enqueue(int i, int j, int src_i, int src_j, CellDataPriorityQueue &Q) {

	auto index = ComputeCellIndexByMap(i, j);
	if (mark_vec_->at(index)) {
		return;
	}

	int di = std::abs(i - src_i);
	int dj = std::abs(j - src_j);
	double distance = cached_distance_map_->distances_mat_[di][dj];

	if (distance > cached_distance_map_->cell_radius_) {
		return;
	}

	this->cells_vec_[index].occ_dist = distance * this->scale_;
    // 其实最后我们需要的东西是什么？激光终点落入到某一个格子，这个格子对最近的占用格子的距离是确定下来不变的，所以free格子分为两类
	// 一类围绕在占用格子周围42*42（可设定），我们计算这些free格子到最近的占用格子的距离并记录；另一类不在42*42的周围，
	// 我们直接赋予它距离为max_occ_dist
	CellData cell_data(static_cast<unsigned int>(i),
					   static_cast<unsigned int>(j),
					   static_cast<unsigned int>(src_i),
					   static_cast<unsigned int>(src_j),
					   std::bind(&AmclMap::GetCellOccDistByCoord, this, std::placeholders::_1, std::placeholders::_2));
	Q.push(cell_data);
	mark_vec_->at(index) = 1;

}

}// roborts_localization

